#!/bin/bash
cp /work/ssl/* /work/cassl/
node /work/server.js
