AnyProxy
----------------

[![NPM version][npm-image]][npm-url]
[![node version][node-image]][node-url]
[![npm download][download-image]][download-url]

[npm-image]: https://img.shields.io/npm/v/anyproxy.svg?style=flat-square
[npm-url]: https://npmjs.org/package/anyproxy
[node-image]: https://img.shields.io/badge/node.js-%3E=_6.0.0-green.svg?style=flat-square
[node-url]: http://nodejs.org/download/
[download-image]: https://img.shields.io/npm/dm/anyproxy.svg?style=flat-square
[download-url]: https://npmjs.org/package/anyproxy

AnyProxy is A fully configurable HTTP/HTTPS proxy in NodeJS.

Home page : [AnyProxy.io](http://anyproxy.io)

Issue: https://github.com/alibaba/anyproxy/issues

AnyProxy是一个基于NodeJS的，可供插件配置的HTTP/HTTPS代理服务器。

主页：[AnyProxy.io](http://anyproxy.io)，访问可能需要稳定的国际网络环境

![](https://gw.alipayobjects.com/zos/rmsportal/gUfcjGxLONndTfllxynC.jpg@_90q)

----------------

Legacy doc of version 3.x : https://github.com/alibaba/anyproxy/wiki/3.x-docs